# 4-2-26 Playing with Claude, Alcatraz planning

Created: April 2, 2026
Productive/Valuable?: No
Tags: Daily

I’m trying out Claude. 

# Things to try

1. Sort gmail boxes
2. Get personal notion more organized. 
3. Fun/useful coding projects for home (like what?)
4. Learn how to code for Verilog
5. Cantonese subtitles
6. Decked out HKK website

I think I remember how old Lothar is. He’s at least 40 I think. I think he started undergrad late. 

# Planning

- [ ]  Investments
- [ ]  Book flight home in July
- [ ]  Contact lens appointment
- [ ]  David and Chrstina
    - [x]  Alcatraz https://www.alcatrazislandtickets.com/Alcatraz-Tickets/?msclkid=a866501ac8bb1fd1166839d20eb79cec
    - [ ]  Cherry Blossom garden https://gggp.org/cherryblossoms/

## Alcatraz planning

So get to the Fisherman’s wharf around 10:30 or 11. Chill out, have lunch and then go to Alcatraz. 12:30 pm tour. 

![image.png](image.png)

![image.png](image%201.png)

![image.png](image%202.png)

## Cherry blossoms

Wait for reply from D&C

# Learning about Claude

There seems to be three big features that Claude has:

1. Chat (just normal chat like ChatGPT). Claude seems leagues better than chatGPT though. 
2. Cowork. You can make a plan with Claude and dispatch it to do a variety of tasks like automating response or sorting through files, or summarizing a meeting. 
3. Code. I’ve been using Claude code a lot. Holy cow, it’s kind of incredible. It can just code for you on basically any project you can think of. It’s helping me sort out the huge mess of emails in my personal gmail. 

![image.jpeg](image.jpeg)

![image.jpeg](image%201.jpeg)

![image.jpeg](image%202.jpeg)

![image.jpeg](image%203.jpeg)

![image.jpeg](image%204.jpeg)

![image.jpeg](image%205.jpeg)

![image.jpeg](image%206.jpeg)

![image.jpeg](image%207.jpeg)

![image.jpeg](image%208.jpeg)

![image.jpeg](image%209.jpeg)

![image.jpeg](image%2010.jpeg)

![image.jpeg](image%2011.jpeg)

![image.jpeg](image%2012.jpeg)

![image.jpeg](image%2013.jpeg)

![image.jpeg](image%2014.jpeg)

![image.jpeg](image%2015.jpeg)

![image.jpeg](image%2016.jpeg)

![image.jpeg](image%2017.jpeg)

![image.jpeg](image%2018.jpeg)

![image.jpeg](image%2019.jpeg)

## Cowork

You basically make a plan with Claude and it will go do it on its own. What is somethingn I want to run in the background… 

Perhaps 

1. Scanning my directories and organizing them better?
2.  Or perhaps Researching my investments?
3. Website creation?
4. Keeping track of a dictionary or some sort

Make sure you use Claude safely. 

https://support.claude.com/en/articles/12902428-using-claude-in-chrome-safely